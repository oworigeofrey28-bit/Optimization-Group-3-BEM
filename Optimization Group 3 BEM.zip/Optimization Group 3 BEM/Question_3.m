function factory_optimization_benchmark()
    clc; clear; close all;

    % 1. Problem Formulation & Bounds
    lb = [0.0, 0.0]; ub = [40.0, 40.0]; x0 = [10.0, 10.0];
    obj = @(x) -(40*x(1) + 30*x(2));
    con = @(x) deal([2*x(1)+x(2)-40; x(1)+2*x(2)-50], []);
    pen = @(x) obj(x) + 1e5*sum(max(0, [2*x(1)+x(2)-40; x(1)+2*x(2)-50]).^2);

    solvers = {'fmincon','patternsearch','simulannealbnd','particleswarm','ga','surrogateopt'};
    t = zeros(1,6); c = zeros(1,6); x = cell(1,6);

    % 2. Execute Benchmarks
    tic; [x{1},f] = fmincon(obj, x0, [],[],[],[], lb, ub, con, optimoptions('fmincon','Display','off')); t(1)=toc; c(1)=-f;
    tic; [x{2},f] = patternsearch(obj, x0, [],[],[],[], lb, ub, con, optimoptions('patternsearch','Display','off')); t(2)=toc; c(2)=-f;
    tic; [x{3},~] = simulannealbnd(pen, x0, lb, ub, optimoptions('simulannealbnd','Display','off')); t(3)=toc; c(3)=-obj(x{3});
    tic; [x{4},~] = particleswarm(pen, 2, lb, ub, optimoptions('particleswarm','Display','off')); t(4)=toc; c(4)=-obj(x{4});
    tic; [x{5},f] = ga(obj, 2, [],[],[],[], lb, ub, con, optimoptions('ga','Display','off')); t(5)=toc; c(5)=-f;
    
    s_prob = struct('objective',obj,'lb',lb,'ub',ub,'solver','surrogateopt','options',optimoptions('surrogateopt','Display','off','MaxFunctionEvaluations',150));
    s_prob.constraints = @(w) struct('Inequalities', [2*w(1)+w(2)-40; w(1)+2*w(2)-50], 'Equalities', []);
    tic; [x{6},f] = surrogateopt(s_prob); t(6)=toc; c(6)=-f;

    % 3. Print Results (FIXED: Corrected MATLAB indexing style)
    for i = 1:6
        fprintf('%-15s | Time: %6.4fs | Max Profit: %7.2f | Units: [%4.1f, %4.1f]\n', solvers{i}, t(i), c(i), x{i}(1), x{i}(2));
    end

    % 4. Generate Visualizations (Safe formatting order)
    render_factory_plots(x{1}, solvers, t);
end

function render_factory_plots(opt_x, solvers, times)
    % --- FIGURE 1: Solution Space ---
    fig1 = figure('Name', 'Production Feasible Frontier'); movegui(fig1, 'left');
    x1_line = linspace(0, 30, 100);
    plot(x1_line, 40 - 2*x1_line, 'b-', 'LineWidth', 1.5); hold on;
    plot(x1_line, (50 - x1_line)/2, 'r-', 'LineWidth', 1.5);
    plot(opt_x(1), opt_x(2), 'kp', 'MarkerSize', 12, 'MarkerFaceColor', 'y');
    xlim([0, 25]); ylim([0, 30]); grid on;
    title('Production Feasible Frontier Region'); xlabel('Units of Product A'); ylabel('Units of Product B');
    legend('Machine Cap (2A+B<=40)', 'Labor Cap (A+2B<=50)', 'Optimum', 'Location', 'northeast');

    % --- FIGURE 2: Speed Profile ---
    fig2 = figure('Name', 'Solver Time Profile'); movegui(fig2, 'right');
    b = bar(categorical(solvers), times, 'FaceColor', [0.4 0.6 0.4]);
    title('Solver Execution Time Profile'); xlabel('Solver Strategy'); ylabel('Seconds'); grid on;
    text(b.XEndPoints, b.YEndPoints, string(num2cell(round(times, 4))) + " s", ...
         'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
end
