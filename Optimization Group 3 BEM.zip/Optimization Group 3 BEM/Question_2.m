function portfolio_optimization_benchmark()
    clc; clear; close all;
    
    % 1. Problem Formulation & Bounds
    lb =[0.0,0.0]; ub =[1.0,1.0]; x0 = [0.5, 0.5]; H = [0.04, 0.01; 0.01, 0.02];
    obj = @(w) 0.5 * (w(1)^2 * H(1,1) + 2*w(1)*w(2)*H(1,2) + w(2)^2 * H(2,2));
    con = @(w) deal(-0.10*w(1) - 0.06*w(2) + 0.08, w(1) + w(2) - 1);
    pen = @(w) obj(w) + 1e4*max(0, -0.10*w(1)-0.06*w(2)+0.08)^2 + 1e4*(w(1)+w(2)-1)^2;

    solvers = {'fmincon','patternsearch','simulannealbnd','particleswarm','ga','surrogateopt'};
    t = zeros(1,6); c = zeros(1,6); w = cell(1,6);
    off = optimoptions('fmincon','Display','off');

    % 2. Execute Benchmarks
    tic; [w{1},c(1)] = fmincon(obj, x0, [],[],[],[], lb, ub, con, off); t(1)=toc;
    tic; [w{2},c(2)] = patternsearch(obj, x0, [],[],[],[], lb, ub, con, optimoptions('patternsearch','Display','off')); t(2)=toc;
    tic; [w{3},~] = simulannealbnd(pen, x0, lb, ub, optimoptions('simulannealbnd','Display','off')); t(3)=toc; c(3)=obj(w{3});
    tic; [w{4},~] = particleswarm(pen, 2, lb, ub, optimoptions('particleswarm','Display','off')); t(4)=toc; c(4)=obj(w{4});
    tic; [w{5},c(5)] = ga(obj, 2, [],[],[],[], lb, ub, con, optimoptions('ga','Display','off')); t(5)=toc;
    
    s_prob = struct('objective',obj,'lb',lb,'ub',ub,'solver','surrogateopt','options',optimoptions('surrogateopt','Display','off','MaxFunctionEvaluations',150));
    s_prob.constraints = @(x) struct('Inequalities',-0.10*x(1)-0.06*x(2)+0.08, 'Equalities',x(1)+x(2)-1);
    tic; [w{6},c(6)] = surrogateopt(s_prob); t(6)=toc;

    % 3. Print Results
    for i = 1:6
        fprintf('%-15s | Time: %6.4fs | Cost: %8.5f | Weights: [%4.2f, %4.2f]\n', solvers{i}, t(i), c(i), w{i}(1), w{i}(2));
    end

    % 4. Generate Visualizations (Outputs both inline and as separate windows)
    render_plots(H, w{1}, solvers, t);
end

function render_plots(H, opt_w, solvers, times)
    % --- FIGURE 1: Solution Space ---
    fig1 = figure('Name', 'Portfolio Solution Space Grid'); 
    movegui(fig1, 'left'); 
    
    [W1, W2] = meshgrid(linspace(0,1,100), linspace(0,1,100));
    Z = 0.5 * (W1.^2*H(1,1) + 2*W1.*W2*H(1,2) + W2.^2*H(2,2));
    
    contour(W1, W2, Z, 25, 'LineWidth', 0.8); hold on;
    plot(linspace(0,1,100), 1 - linspace(0,1,100), 'r--', 'LineWidth', 2);
    plot(opt_w(1), opt_w(2), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    title('Portfolio Solution Space'); xlabel('w1'); ylabel('w2'); grid on;
    legend('Risk Contours', 'w1 + w2 = 1', 'Optimum', 'Location', 'northeast');

    % --- FIGURE 2: Execution Time Profile (FIXED RENDERING FLOW) ---
    fig2 = figure('Name', 'Solver Execution Time Profile'); 
    movegui(fig2, 'right'); 
    
    % 1. Render base bar chart
    b = bar(categorical(solvers), times, 'FaceColor', [0.2 0.5 0.7]);
    
    % 2. Set labels and axes rules first (Forces the graphics handle to finish scaling)
    title('Solver Execution Time Profile'); 
    xlabel('Solver'); 
    ylabel('Seconds'); 
    grid on;
    
    % 3. Apply text markers after scale initialization completes
    xtips = b.XEndPoints;
    ytips = b.YEndPoints;
    labels = string(num2cell(round(times, 4))) + " s";
    text(xtips, ytips, labels, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
end


