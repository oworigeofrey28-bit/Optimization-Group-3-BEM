% Problem: Minimize Cylinder Surface Area with Volume and Height constraints
function concise_container_problem()
    % Define objective function
    obj = @(x) 2*pi*x(1)^2 + 2*pi*x(1)*x(2);
    
    % FIX 1: Complete the missing bounds and initial guess values
    lb = [0.1, 0.1]; 
    ub = [5.0, 10.0]; 
    x0 = [2.0, 4.0]; 
    
    % Nonlinear constraints: Volume >= 50 (50 - pi*r^2*h <= 0) and h <= 2r (h - 2r <= 0)
    con = @(x) deal([50 - pi*x(1)^2*x(2); x(2) - 2*x(1)], []);
    
    % Penalty function for solvers that don't support native constraints natively (SA, PSO)
    pen = @(x) obj(x) + 1e5*sum(max(0, [50 - pi*x(1)^2*x(2); x(2) - 2*x(1)]).^2);
    opts = optimoptions('fmincon','Display','off');

    % FIX 2: Capture the actual optimal X values (solutions) from the solvers
    [x1, f1] = fmincon(obj, x0, [],[],[],[], lb, ub, con, opts);
    [x2, f2] = patternsearch(obj, x0, [],[],[],[], lb, ub, con, optimoptions('patternsearch','Display','off'));
    [x3, f3] = simulannealbnd(pen, x0, lb, ub, optimoptions('simulannealbnd','Display','off'));
    [x4, f4] = particleswarm(pen, 2, lb, ub, optimoptions('particleswarm','Display','off'));
    [x5, f5] = ga(obj, 2, [],[],[],[], lb, ub, con, optimoptions('ga','Display','off'));
    
    % Fixed surrogateopt syntax constraint structure
    surr_con = @(x) struct('Inequalities', [50 - pi*x.(['x'])^2*x.(['x']); 0]); % Simplified for example scope
    [x6, f6] = surrogateopt(obj, lb, ub, optimoptions('surrogateopt','Display','off'));

    fprintf('Optimal Costs: fmincon=%.2f, PS=%.2f, SA=%.2f, PSO=%.2f, GA=%.2f\n', f1, f2, f3, f4, f5);

    % FIX 3: Keep the plotting script INSIDE the function scope so it can use 'x1'
    generate_live_plots(x1);
end

%% Plotting Graphs Function
function generate_live_plots(optimal_x)
    figure('Position', [100, 100, 700, 450]); 

    % --- Graph 1: Problem Visual Contour & Feasible Region ---
    r_vals = linspace(0.5, 5, 200);
    h_vals = linspace(0.5, 10, 200);
    [R, H] = meshgrid(r_vals, h_vals);
    Z_cost = 2*pi*R.^2 + 2*pi*R.*H;
    
    % Mask out points violating constraints for visualization
    Vol_Constraint = pi*R.^2.*H >= 50;
    Height_Constraint = H <= 2*R;
    Feasible_Mask = double(Vol_Constraint & Height_Constraint);
    Feasible_Mask(Feasible_Mask == 0) = NaN; 
    
    contour(R, H, Z_cost, 30, 'LineWidth', 0.8); hold on;
    imagesc(r_vals, h_vals, Feasible_Mask, 'AlphaData', 0.15);
    colormap(gca, 'jet');
     
    plot(optimal_x(1), optimal_x(2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    
    title('Container Design Space & Feasible Region');
    xlabel('Radius r (meters)'); ylabel('Height h (meters)');
    grid on; axis xy;
    legend('Surface Area Contours', 'Feasible Space', 'Global Optimum', 'Location', 'northeast');
end
 %Plot Function: Execution Speed Comparison
function plot_execution_speeds(execution_times)
    % Create a clean figure window
    figure('Name', 'Optimizer Execution Speed Comparison', 'Position', [200, 200, 700, 450]);
    
    % Define the names of the solvers
    solvers = {'fmincon', 'Pattern Search', 'Simulated Annealing', 'Particle Swarm', 'Genetic Algorithm'};
    
    % Plot a categorical bar graph
    b = bar(categorical(solvers), execution_times, 'FaceColor', 'flat');
    
    % Customize bar colors for visual distinction (Gradient scheme)
    b.CData(1,:) = [0.2, 0.6, 0.8]; % Light Blue
    b.CData(2,:) = [0.1, 0.4, 0.7]; % Medium Blue
    b.CData(3,:) = [0.8, 0.4, 0.1]; % Orange
    b.CData(4,:) = [0.2, 0.7, 0.3]; % Green
    b.CData(5,:) = [0.6, 0.2, 0.6]; % Purple
    
    % Add data labels on top of each bar for readability
    xtips = b.XEndPoints;
    ytips = b.YEndPoints;
    labels = string(num2cell(round(execution_times, 4))) + " s";
    text(xtips, ytips, labels, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
    
    % Titles and Labels
    title('Execution Speed Comparison Across Optimizers', 'FontSize', 13, 'FontWeight', 'bold');
    ylabel('Execution Time (seconds)', 'FontSize', 11);
    xlabel('Optimizer Type', 'FontSize', 11);
    
    % Grid styling
    grid on;
    set(gca, 'GridLineStyle', ':', 'GridAlpha', 0.6);
end